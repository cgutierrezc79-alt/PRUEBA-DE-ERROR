/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/

import React from 'react';

const Hero: React.FC = () => {
  const handleNavClick = (e: React.MouseEvent<HTMLAnchorElement>, targetId: string) => {
    e.preventDefault();
    const element = document.getElementById(targetId);
    if (element) {
      const headerOffset = 85;
      const elementPosition = element.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.scrollY - headerOffset;

      window.scrollTo({
        top: offsetPosition,
        behavior: "smooth"
      });
      
      try {
        window.history.pushState(null, '', `#${targetId}`);
      } catch (err) {
        // Ignore SecurityError in restricted environments
      }
    }
  };

  return (
    <section className="relative w-full min-h-[85vh] md:min-h-[90vh] pt-28 pb-16 flex items-center justify-center overflow-hidden bg-gradient-to-b from-[#FFF5F8] via-[#FFEDF4] to-[#FCE7F3]">
      
      {/* Decorative Cloud & Pearl Ornaments */}
      <div className="absolute top-16 left-8 w-44 h-44 bg-[#FFD6E8]/30 rounded-full blur-3xl pointer-events-none animate-float-soft"></div>
      <div className="absolute bottom-12 right-12 w-64 h-64 bg-[#E9D5FF]/40 rounded-full blur-3xl pointer-events-none animate-float-soft" style={{ animationDelay: '2s' }}></div>

      <div className="max-w-[1400px] mx-auto px-6 md:px-12 w-full grid grid-cols-1 lg:grid-cols-12 gap-12 items-center relative z-10">
        
        {/* Left Column: Text & Hero Info */}
        <div className="lg:col-span-7 space-y-6 text-center lg:text-left">
          
          {/* Top Pill Badges */}
          <div className="flex flex-wrap items-center justify-center lg:justify-start gap-2">
            <span className="font-label text-[10px] uppercase tracking-[0.12em] text-[#1A1A1A] bg-[#FFD6E8] px-4 py-1.5 rounded-full border border-[#FFD6E8] shadow-sm flex items-center gap-1.5 font-bold">
              <span>🎀</span>
              <span>Lollipop Soft Girl Store</span>
            </span>
            <span className="font-label text-[10px] uppercase tracking-[0.12em] text-[#1A1A1A] bg-[#E9D5FF] px-3.5 py-1.5 rounded-full border border-[#FFD6E8] shadow-sm">
              ✨ Coquette & Balletcore
            </span>
          </div>

          {/* Main Title */}
          <h1 className="text-5xl sm:text-6xl md:text-7xl font-title font-extrabold text-[#1A1A1A] tracking-tight leading-[1.1]">
            Dulzura, Encanto y <br className="hidden sm:inline" />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#C87D8E] via-[#A65B6D] to-[#9C5389]">
              Estilo Soft Girl 🎀
            </span>
          </h1>

          {/* Body Description */}
          <p className="max-w-xl mx-auto lg:mx-0 text-base md:text-lg text-[#6B5A60] font-normal leading-relaxed">
            Explora nuestro catálogo exclusivo de prendas en tejidos suaves, accesorios con lazos y objetos con alma táctil. Un universo limpio, dulce y elevado.
          </p>

          {/* Actions & Perks */}
          <div className="pt-4 flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-4">
            {/* Pastel Yellow CTA Pill */}
            <a 
              href="#products" 
              onClick={(e) => handleNavClick(e, 'products')}
              className="w-full sm:w-auto px-8 py-4 bg-[#FFD6A8] hover:bg-[#ffc88f] text-[#1A1A1A] rounded-full font-title font-bold text-sm uppercase tracking-wider transition-all duration-300 shadow-[0_8px_20px_rgba(255,214,232,0.6)] hover:scale-105 hover:shadow-xl border border-[#FFD6E8] flex items-center justify-center gap-2"
            >
              <span>Explorar Catálogo</span>
              <span className="text-base">🛍️</span>
            </a>

            <a 
              href="#about" 
              onClick={(e) => handleNavClick(e, 'about')}
              className="w-full sm:w-auto px-7 py-4 bg-white/80 hover:bg-white text-[#1A1A1A] rounded-full font-title font-semibold text-sm uppercase tracking-wider transition-all duration-300 border border-[#FFD6E8] shadow-sm flex items-center justify-center gap-2"
            >
              <span>Filosofía Coco Rose</span>
              <span>🎀</span>
            </a>
          </div>

          {/* Perlitas & Trust tags */}
          <div className="pt-6 border-t border-dashed border-[#FFD6E8] flex flex-wrap items-center justify-center lg:justify-start gap-6 text-xs text-[#6B5A60]">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-[#FFD6E8] border border-[#1A1A1A]/20"></span>
              <span className="font-medium">Envíos Cuidados</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-[#E9D5FF] border border-[#1A1A1A]/20"></span>
              <span className="font-medium">Materiales Premium</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-[#FFD6A8] border border-[#1A1A1A]/20"></span>
              <span className="font-medium">Detalles Artesanales</span>
            </div>
          </div>

        </div>

        {/* Right Column: Featured Moodboard Card / Soft Frame */}
        <div className="lg:col-span-5 relative">
          
          {/* Main Card Frame with lace border */}
          <div className="card-softgirl p-4 md:p-6 relative overflow-hidden group">
            
            {/* Top Tag */}
            <div className="flex justify-between items-center mb-4 pb-3 border-b border-dashed border-[#FFD6E8]">
              <span className="font-label text-[10px] text-[#1A1A1A] bg-[#E9D5FF] px-3 py-1 rounded-full">
                ✨ LOLLIPOP ESSENTIALS
              </span>
              <span className="text-xs font-semibold text-[#6B5A60]">
                Edición 2025 🎀
              </span>
            </div>

            {/* Image */}
            <div className="relative aspect-[4/5] rounded-2xl overflow-hidden bg-[#FFF5F8] border border-[#FFD6E8]">
              <img 
                src="https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&q=80&w=1000" 
                alt="Lollipop Soft Girl aesthetic look" 
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#1A1A1A]/40 via-transparent to-transparent"></div>
              
              <div className="absolute bottom-4 left-4 right-4 bg-white/95 backdrop-blur-md p-4 rounded-2xl border border-[#FFD6E8] shadow-lg">
                <span className="font-label text-[9px] text-[#C87D8E]">MUSA COCO ROSE</span>
                <p className="font-title font-bold text-sm text-[#1A1A1A]">Kimono Lino & Rosa Polvo</p>
                <p className="text-xs text-[#6B5A60] mt-0.5">Tejidos naturales en capas fluidas</p>
              </div>
            </div>

            {/* Floating Soft Perlita Badge */}
            <div className="absolute -bottom-3 -left-3 bg-[#FFD6A8] text-[#1A1A1A] p-3 rounded-2xl border border-[#FFD6E8] shadow-md flex items-center gap-2 font-title font-bold text-xs">
              <span className="text-base">🌸</span>
              <span>100% Orgánico</span>
            </div>

          </div>

        </div>

      </div>

    </section>
  );
};

export default Hero;
