/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/


import React from 'react';
import { Product } from '../types';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  items: Product[];
  onRemoveItem: (index: number) => void;
  onCheckout: () => void;
}

const CartDrawer: React.FC<CartDrawerProps> = ({ isOpen, onClose, items, onRemoveItem, onCheckout }) => {
  const total = items.reduce((sum, item) => sum + item.price, 0);

  return (
    <>
      {/* Backdrop */}
      <div 
        className={`fixed inset-0 bg-[#1A1A1A]/30 backdrop-blur-sm z-[60] transition-opacity duration-500 ${
          isOpen ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'
        }`}
        onClick={onClose}
      />

      {/* Drawer */}
      <div 
        className={`fixed inset-y-0 right-0 w-full md:w-[420px] bg-gradient-to-b from-[#FFF5F8] via-[#FFEDF4] to-[#FCE7F3] z-[70] shadow-[0_8px_32px_rgba(255,214,232,0.6)] transform transition-transform duration-500 ease-in-out border-l border-[#FFD6E8] flex flex-col ${
          isOpen ? 'translate-x-0' : 'translate-x-full'
        }`}
      >
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-dashed border-[#FFD6E8]">
          <div className="flex items-center gap-2">
            <span className="text-xl">🎀</span>
            <h2 className="text-xl font-title font-extrabold text-[#1A1A1A]">Bolsa de Compras ({items.length})</h2>
          </div>
          <button 
            onClick={onClose} 
            className="w-8 h-8 rounded-full bg-white border border-[#FFD6E8] flex items-center justify-center text-[#1A1A1A] hover:bg-[#FFF5F8] transition-all shadow-sm"
          >
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-4 h-4">
              <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        {/* Items List */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          {items.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center space-y-3 opacity-80">
              <div className="w-16 h-16 rounded-full bg-white border border-[#FFD6E8] flex items-center justify-center text-2xl shadow-sm">
                🛍️
              </div>
              <p className="font-title font-bold text-sm text-[#1A1A1A]">Tu bolsa está vacía.</p>
              <p className="text-xs text-[#6B5A60]">¡Añade tus prendas y accesorios soft favoritos!</p>
            </div>
          ) : (
            items.map((item, idx) => (
              <div key={`${item.id}-${idx}`} className="flex gap-4 p-3.5 bg-white rounded-3xl border border-[#FFD6E8] shadow-[0_4px_16px_rgba(255,214,232,0.3)] animate-fade-in-up">
                <div className="w-20 h-24 bg-[#FFF5F8] rounded-2xl overflow-hidden flex-shrink-0 border border-[#FFD6E8]">
                  <img src={item.imageUrl} alt={item.name} className="w-full h-full object-cover" />
                </div>
                <div className="flex-1 flex flex-col justify-between py-0.5">
                  <div>
                    <div className="flex justify-between items-start gap-2">
                        <h3 className="font-title font-bold text-[#1A1A1A] text-sm leading-snug">{item.name}</h3>
                        <span className="text-sm font-title font-extrabold text-[#1A1A1A]">${item.price}</span>
                    </div>
                    <p className="font-label text-[9px] text-[#C87D8E] uppercase tracking-wider font-semibold mt-0.5">{item.category}</p>
                    
                    {/* Selected Options */}
                    <div className="flex flex-wrap items-center gap-1.5 mt-2">
                      {item.selectedSize && (
                        <span className="bg-[#FFF5F8] px-2 py-0.5 rounded-full text-[9px] font-bold text-[#1A1A1A] border border-[#FFD6E8]">
                          Talla: {item.selectedSize}
                        </span>
                      )}
                      {item.selectedColor && (
                        <span className="bg-[#E9D5FF] px-2 py-0.5 rounded-full text-[9px] font-bold text-[#1A1A1A] border border-[#FFD6E8]">
                          Color: {item.selectedColor}
                        </span>
                      )}
                    </div>
                  </div>

                  <button 
                    onClick={() => onRemoveItem(idx)}
                    className="text-[10px] font-label uppercase tracking-widest text-[#C87D8E] hover:text-[#1A1A1A] self-start transition-colors mt-2"
                  >
                    Quitar ✕
                  </button>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Footer */}
        <div className="p-6 border-t border-dashed border-[#FFD6E8] bg-white/70 backdrop-blur-sm">
          <div className="flex justify-between items-center mb-3">
            <span className="font-label text-[10px] uppercase tracking-widest text-[#6B5A60]">Subtotal</span>
            <span className="text-2xl font-title font-extrabold text-[#1A1A1A]">${total}</span>
          </div>
          <p className="text-[10px] text-[#6B5A60] mb-5 text-center">Envío gratuito disponible para todas las prendas 🎀</p>
          <button 
            onClick={onCheckout}
            disabled={items.length === 0}
            className="w-full py-4 bg-[#FFD6A8] text-[#1A1A1A] font-title font-extrabold text-xs uppercase tracking-wider rounded-full hover:bg-[#ffc98f] transition-all disabled:opacity-50 disabled:cursor-not-allowed shadow-[0_4px_16px_rgba(255,214,168,0.6)] border border-[#FFD6E8] flex items-center justify-center gap-2"
          >
            <span>Finalizar Compra</span>
            <span>🎀</span>
          </button>
        </div>
      </div>
    </>
  );
};

export default CartDrawer;
