/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/


import React from 'react';
import { JournalArticle } from '../types';

interface JournalDetailProps {
  article: JournalArticle;
  onBack: () => void;
}

const JournalDetail: React.FC<JournalDetailProps> = ({ article, onBack }) => {
  return (
    <div className="min-h-screen bg-gradient-to-b from-[#FFF5F8] via-[#FFEDF4] to-[#FCE7F3] animate-fade-in-up">
       {/* Hero Image for Article */}
       <div className="w-full h-[45vh] md:h-[55vh] relative overflow-hidden">
          <img 
             src={article.image} 
             alt={article.title} 
             className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-[#1A1A1A]/20"></div>
       </div>

       <div className="max-w-3xl mx-auto px-6 md:px-12 -mt-24 relative z-10 pb-24">
          <div className="bg-white p-8 md:p-14 shadow-[0_8px_32px_rgba(255,214,232,0.5)] border border-[#FFD6E8] rounded-3xl">
             <div className="flex justify-between items-center mb-8 border-b border-dashed border-[#FFD6E8] pb-6">
                <button 
                  onClick={onBack}
                  className="group flex items-center gap-2 font-label text-[10px] uppercase tracking-[0.12em] text-[#1A1A1A] bg-[#FFF5F8] px-4 py-2 rounded-full border border-[#FFD6E8] hover:bg-white transition-all shadow-sm"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.8} stroke="currentColor" className="w-4 h-4 group-hover:-translate-x-1 transition-transform">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 19.5L8.25 12l7.5-7.5" />
                  </svg>
                  <span>Volver al Diario</span>
                  <span>🎀</span>
                </button>
                <span className="font-label text-[10px] uppercase text-[#C87D8E] bg-[#E9D5FF] px-3 py-1 rounded-full border border-[#FFD6E8]">
                  {article.date}
                </span>
             </div>

             <h1 className="text-3xl md:text-5xl font-title font-extrabold text-[#1A1A1A] mb-8 leading-tight text-center">
               {article.title}
             </h1>

             <div className="prose prose-pink prose-base mx-auto font-normal leading-relaxed text-[#6B5A60]">
               {article.content}
             </div>
             
             <div className="mt-12 pt-8 border-t border-dashed border-[#FFD6E8] flex flex-col items-center gap-2">
                 <span className="font-title font-extrabold text-xl text-[#1A1A1A] flex items-center gap-2">
                   <span>Coco Rose</span>
                   <span>🎀</span>
                 </span>
                 <span className="font-label text-[9px] text-[#6B5A60] uppercase tracking-widest">
                   Lollipop Soft Girl Store
                 </span>
             </div>
          </div>
       </div>
    </div>
  );
};

export default JournalDetail;
