/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/


import React from 'react';

const Features: React.FC = () => {
  return (
    <section className="bg-[#FFF5F8]">
      {/* Feature Block 1 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 min-h-[60vh]">
        <div className="order-2 lg:order-1 relative h-[400px] lg:h-auto overflow-hidden">
           <img 
             src="https://images.unsplash.com/photo-1618220179428-22790b461013?auto=format&fit=crop&q=80&w=1200" 
             alt="Natural Soft Textures" 
             className="absolute inset-0 w-full h-full object-cover hover:scale-105 transition-transform duration-700"
           />
        </div>
        <div className="order-1 lg:order-2 flex flex-col justify-center p-10 lg:p-20 bg-[#FCE7F3] space-y-4">
           <span className="font-label text-[10px] uppercase tracking-[0.12em] text-[#1A1A1A] bg-[#FFD6E8] px-3.5 py-1 rounded-full border border-[#FFD6E8] w-fit">
             🎀 Filosofía Soft
           </span>
           <h3 className="text-3xl md:text-4xl font-title font-extrabold text-[#1A1A1A] leading-tight">
             Detalles delicados que <br/> perduran.
           </h3>
           <p className="text-sm md:text-base text-[#6B5A60] font-normal leading-relaxed max-w-md">
             Cada pieza de Coco Rose está pensada para integrarse armoniosamente en tu rutina, brindando calidez táctil, suavidad y estética coquette.
           </p>
        </div>
      </div>

      {/* Feature Block 2 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 min-h-[60vh]">
        <div className="flex flex-col justify-center p-10 lg:p-20 bg-[#E9D5FF] text-[#1A1A1A] space-y-4">
           <span className="font-label text-[10px] uppercase tracking-[0.12em] text-[#1A1A1A] bg-white px-3.5 py-1 rounded-full border border-[#FFD6E8] w-fit font-bold">
             ✨ SECCIÓN GLAM
           </span>
           <h3 className="text-3xl md:text-4xl font-title font-extrabold text-[#1A1A1A] leading-tight">
             Estética Dulce & Elevada.
           </h3>
           <p className="text-sm md:text-base text-[#1A1A1A]/80 font-normal leading-relaxed max-w-md">
             Nuestros objetos y prendas combinan tonos pastel, lazos minimalistas y acabados de alta calidad para un universo personal inolvidable.
           </p>
        </div>
        <div className="relative h-[400px] lg:h-auto overflow-hidden">
           <img 
             src="https://images.pexels.com/photos/6801917/pexels-photo-6801917.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1" 
             alt="Coquette aesthetic moment" 
             className="absolute inset-0 w-full h-full object-cover hover:scale-105 transition-transform duration-700"
           />
        </div>
      </div>
    </section>
  );
};

export default Features;
