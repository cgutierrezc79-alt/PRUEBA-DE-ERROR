/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/


import React from 'react';
import { Product } from '../types';

interface ProductCardProps {
  product: Product;
  onClick: (product: Product) => void;
  onQuickView?: (product: Product, e: React.MouseEvent) => void;
  isWishlisted?: boolean;
  onToggleWishlist?: (productId: string, e: React.MouseEvent) => void;
}

const ProductCard: React.FC<ProductCardProps> = ({ 
  product, 
  onClick, 
  onQuickView, 
  isWishlisted = false, 
  onToggleWishlist 
}) => {
  return (
    <div 
      className="group flex flex-col justify-between h-full bg-white p-5 rounded-3xl border border-[#FFD6E8] shadow-[0_8px_24px_rgba(255,214,232,0.4)] hover:shadow-[0_12px_32px_rgba(255,214,232,0.6)] transition-all duration-300 cursor-pointer relative"
      onClick={() => onClick(product)}
    >
      <div>
        {/* Image Frame */}
        <div className="relative w-full aspect-[4/5] overflow-hidden rounded-2xl bg-[#FFF5F8] mb-4 border border-[#FFD6E8]">
          <img 
            src={product.imageUrl} 
            alt={product.name} 
            className="w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-105"
          />
          
          {/* Top Badges */}
          <div className="absolute top-3 left-3 right-3 flex justify-between items-center z-10 pointer-events-none">
            {product.isNew ? (
              <span className="bg-[#E9D5FF] text-[#1A1A1A] font-label text-[10px] px-3 py-1 rounded-full border border-[#FFD6E8] shadow-sm flex items-center gap-1">
                <span>✨</span>
                <span>Nuevo</span>
              </span>
            ) : product.material ? (
              <span className="bg-white/95 backdrop-blur text-[#6B5A60] font-label text-[9px] px-2.5 py-1 rounded-full border border-[#FFD6E8]">
                {product.material.split(' ')[0]}
              </span>
            ) : <span />}

            {/* Wishlist Button */}
            {onToggleWishlist && (
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  onToggleWishlist(product.id, e);
                }}
                className="pointer-events-auto w-8 h-8 rounded-full bg-white/90 backdrop-blur flex items-center justify-center text-[#1A1A1A] hover:scale-110 transition-transform shadow-sm border border-[#FFD6E8]"
                title={isWishlisted ? "Quitar de favoritos" : "Guardar en favoritos"}
              >
                <svg 
                  xmlns="http://www.w3.org/2000/svg" 
                  viewBox="0 0 24 24" 
                  fill={isWishlisted ? "#C87D8E" : "none"} 
                  stroke={isWishlisted ? "#C87D8E" : "currentColor"} 
                  strokeWidth="1.8" 
                  className="w-4 h-4 transition-colors"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" d="M21 8.25c0-2.485-2.099-4.5-4.688-4.5-1.935 0-3.597 1.126-4.312 2.733-.715-1.607-2.377-2.733-4.313-2.733C5.1 3.75 3 5.765 3 8.25c0 7.22 9 12 9 12s9-4.78 9-12z" />
                </svg>
              </button>
            )}
          </div>

          {/* Hover Action Overlay with Pastel Yellow Pill CTA */}
          <div className="absolute inset-0 bg-[#1A1A1A]/10 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end justify-center p-3">
            {onQuickView && (
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  onQuickView(product, e);
                }}
                className="w-full bg-[#FFD6A8] text-[#1A1A1A] py-2.5 rounded-full font-title font-bold text-xs uppercase tracking-wider hover:bg-[#ffc88f] transition-colors shadow-md border border-[#FFD6E8] flex items-center justify-center gap-1.5"
              >
                <span>Vistazo Rápido</span>
                <span>🎀</span>
              </button>
            )}
          </div>
        </div>

        {/* Info */}
        <div className="space-y-1.5">
          <div className="flex justify-between items-start gap-2">
            <div>
              <span className="font-label text-[10px] text-[#C87D8E] bg-[#FFF5F8] px-2.5 py-0.5 rounded-full border border-[#FFD6E8] inline-block mb-1">
                {product.category}
              </span>
              <h3 className="text-base font-title font-bold text-[#1A1A1A] group-hover:text-[#C87D8E] transition-colors line-clamp-1">
                {product.name}
              </h3>
            </div>
            <span className="text-base font-title font-extrabold text-[#1A1A1A] whitespace-nowrap">
              ${product.price}
            </span>
          </div>

          <p className="text-xs text-[#6B5A60] font-normal line-clamp-2 leading-relaxed">
            {product.description}
          </p>
        </div>
      </div>

      {/* Footer Meta */}
      <div className="pt-3 mt-3 border-t border-dashed border-[#FFD6E8] flex items-center justify-between text-xs text-[#6B5A60]">
        {/* Colors swatches */}
        {product.colors && product.colors.length > 0 ? (
          <div className="flex items-center gap-1.5" title={`${product.colors.length} tonos disponibles`}>
            {product.colors.slice(0, 3).map((col, idx) => (
              <span 
                key={idx} 
                className="w-3.5 h-3.5 rounded-full border border-[#FFD6E8] shadow-inner"
                style={{ backgroundColor: col.hex }}
              />
            ))}
            {product.colors.length > 3 && (
              <span className="text-[10px] font-semibold text-[#6B5A60]">+{product.colors.length - 3}</span>
            )}
          </div>
        ) : (
          <span className="font-label text-[9px] text-[#6B5A60]">
            {product.material ? product.material.split(' ')[0] : 'Edición Coco Rose'}
          </span>
        )}

        {/* Sizes or Rating */}
        {product.sizes && product.sizes.length > 0 ? (
          <span className="font-label text-[9px] text-[#1A1A1A] bg-[#E9D5FF]/60 px-2 py-0.5 rounded-full border border-[#FFD6E8]">
            {product.sizes.slice(0, 3).join(', ')}
          </span>
        ) : product.rating ? (
          <div className="flex items-center gap-1 text-[11px] font-semibold text-[#1A1A1A]">
            <span className="text-rose-500">★</span>
            <span>{product.rating}</span>
          </div>
        ) : null}
      </div>
    </div>
  );
};

export default ProductCard;
