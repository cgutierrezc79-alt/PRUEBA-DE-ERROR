/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/


import React, { useState } from 'react';
import { Product } from '../types';

interface ProductDetailProps {
  product: Product;
  onBack: () => void;
  onAddToCart: (product: Product) => void;
}

const ProductDetail: React.FC<ProductDetailProps> = ({ product, onBack, onAddToCart }) => {
  const [selectedImage, setSelectedImage] = useState<string>(product.imageUrl);
  const [selectedSize, setSelectedSize] = useState<string>(product.sizes?.[0] || '');
  const [selectedColor, setSelectedColor] = useState<string>(product.colors?.[0]?.name || '');
  const [addedNotice, setAddedNotice] = useState<boolean>(false);

  const galleryImages = product.gallery && product.gallery.length > 0
    ? Array.from(new Set([product.imageUrl, ...product.gallery]))
    : [product.imageUrl];

  const handleAddToCartClick = () => {
    const customized: Product = {
      ...product,
      selectedSize: selectedSize || undefined,
      selectedColor: selectedColor || undefined,
    };
    onAddToCart(customized);
    setAddedNotice(true);
    setTimeout(() => setAddedNotice(false), 2500);
  };

  return (
    <div className="pt-24 min-h-screen bg-gradient-to-b from-[#FFF5F8] via-[#FFEDF4] to-[#FCE7F3] animate-fade-in-up">
      <div className="max-w-[1800px] mx-auto px-6 md:px-12 pb-24">
        
        {/* Breadcrumb / Back button */}
        <button 
          onClick={onBack}
          className="group flex items-center gap-2 font-label text-[10px] uppercase tracking-[0.12em] text-[#1A1A1A] bg-white px-4 py-2 rounded-full border border-[#FFD6E8] hover:bg-[#FFF5F8] transition-all shadow-sm mb-8"
        >
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-4 h-4 group-hover:-translate-x-1 transition-transform">
            <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 19.5L8.25 12l7.5-7.5" />
          </svg>
          <span>Volver al Catálogo</span>
          <span>🎀</span>
        </button>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20 items-start">
          
          {/* Left Column: Gallery & Main Image */}
          <div className="flex flex-col gap-4">
            <div className="w-full aspect-[4/5] bg-white rounded-3xl overflow-hidden shadow-[0_8px_24px_rgba(255,214,232,0.4)] relative border border-[#FFD6E8] p-3">
              <div className="w-full h-full rounded-2xl overflow-hidden relative">
                <img 
                  src={selectedImage} 
                  alt={product.name} 
                  className="w-full h-full object-cover transition-all duration-500"
                />
                {product.isNew && (
                  <span className="absolute top-4 left-4 bg-[#E9D5FF] text-[#1A1A1A] font-label text-[10px] uppercase px-3 py-1 rounded-full border border-[#FFD6E8] shadow-md flex items-center gap-1">
                    <span>✨</span>
                    <span>Nuevo Lanzamiento</span>
                  </span>
                )}
              </div>
            </div>

            {/* Gallery Thumbnails */}
            {galleryImages.length > 1 && (
              <div className="flex gap-3 overflow-x-auto pb-2">
                {galleryImages.map((img, idx) => (
                  <button
                    key={idx}
                    onClick={() => setSelectedImage(img)}
                    className={`w-20 h-24 rounded-2xl overflow-hidden border-2 transition-all flex-shrink-0 ${
                      selectedImage === img ? 'border-[#1A1A1A] scale-105 shadow-md' : 'border-[#FFD6E8] opacity-70 hover:opacity-100'
                    }`}
                  >
                    <img src={img} alt={`${product.name} ${idx}`} className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Right Column: Product Details */}
          <div className="bg-white p-6 md:p-8 rounded-3xl border border-[#FFD6E8] shadow-[0_8px_24px_rgba(255,214,232,0.4)] flex flex-col justify-start max-w-xl space-y-6">
            
            {/* Header tags */}
            <div>
              <div className="flex items-center gap-3 mb-2">
                <span className="font-label text-[10px] text-[#1A1A1A] uppercase bg-[#FFD6E8] border border-[#FFD6E8] px-3.5 py-1 rounded-full">
                  {product.category}
                </span>
                {product.rating && (
                  <span className="font-label text-[10px] text-[#1A1A1A] bg-[#E9D5FF] px-3 py-1 rounded-full flex items-center gap-1 border border-[#FFD6E8]">
                    ★ {product.rating} ({product.reviewsCount || 18} opiniones)
                  </span>
                )}
              </div>

              <h1 className="text-3xl md:text-4xl font-title font-extrabold text-[#1A1A1A] tracking-tight mt-2">
                {product.name}
              </h1>
              
              <p className="text-sm font-label text-[#C87D8E] mt-1 italic">
                "{product.tagline}"
              </p>

              <div className="text-3xl font-title font-extrabold text-[#1A1A1A] mt-4">
                ${product.price}
              </div>
            </div>

            {/* Description */}
            <div className="border-t border-b border-dashed border-[#FFD6E8] py-5 space-y-3">
              <p className="text-[#6B5A60] leading-relaxed font-normal text-sm">
                {product.longDescription || product.description}
              </p>

              {product.material && (
                <div className="pt-2 text-xs font-medium text-[#1A1A1A] flex items-center gap-2">
                  <span className="font-label text-[10px] text-[#6B5A60]">Material:</span>
                  <span className="bg-[#FFF5F8] border border-[#FFD6E8] px-3 py-1 rounded-full font-label text-[9px] text-[#1A1A1A]">{product.material}</span>
                </div>
              )}
            </div>

            {/* Color Selector */}
            {product.colors && product.colors.length > 0 && (
              <div className="space-y-3">
                <div className="flex justify-between items-center font-label text-[10px]">
                  <span className="text-[#1A1A1A]">Color:</span>
                  <span className="text-[#C87D8E] font-bold">{selectedColor || product.colors[0].name}</span>
                </div>
                <div className="flex gap-3">
                  {product.colors.map((color, idx) => (
                    <button
                      key={idx}
                      onClick={() => setSelectedColor(color.name)}
                      className={`flex items-center gap-2 px-3.5 py-2 rounded-full border text-xs font-semibold transition-all ${
                        selectedColor === color.name
                          ? 'border-[#1A1A1A] bg-[#FFF5F8] shadow-sm'
                          : 'border-[#FFD6E8] bg-white text-[#6B5A60] hover:border-[#1A1A1A]'
                      }`}
                    >
                      <span className="w-4 h-4 rounded-full border border-[#FFD6E8] shadow-inner" style={{ backgroundColor: color.hex }} />
                      <span>{color.name}</span>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Size Selector */}
            {product.sizes && product.sizes.length > 0 && (
              <div className="space-y-3">
                <div className="flex justify-between items-center font-label text-[10px]">
                  <span className="text-[#1A1A1A]">Talla:</span>
                  <span className="text-[#C87D8E] font-bold">{selectedSize || 'Sin seleccionar'}</span>
                </div>
                <div className="flex flex-wrap gap-2.5">
                  {product.sizes.map((size) => (
                    <button 
                      key={size}
                      onClick={() => setSelectedSize(size)}
                      className={`px-5 py-2.5 text-xs font-bold uppercase rounded-full border transition-all duration-200 ${
                        selectedSize === size 
                          ? 'border-[#1A1A1A] bg-[#1A1A1A] text-white shadow-sm' 
                          : 'border-[#FFD6E8] bg-white text-[#6B5A60] hover:border-[#1A1A1A]'
                      }`}
                    >
                      {size}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Add to Cart Actions */}
            <div className="pt-2 space-y-4">
              <button 
                onClick={handleAddToCartClick}
                className="w-full py-4 bg-[#FFD6A8] text-[#1A1A1A] font-title font-bold text-xs uppercase tracking-wider rounded-full hover:bg-[#ffc88f] transition-all shadow-md border border-[#FFD6E8] flex items-center justify-center gap-2"
              >
                <span>Añadir al Carrito — ${product.price}</span>
                <span>🎀</span>
              </button>

              {addedNotice && (
                <div className="p-3 bg-[#E9D5FF] border border-[#FFD6E8] text-[#1A1A1A] text-xs text-center font-bold rounded-full animate-fade-in">
                  ✓ ¡Producto añadido a tu bolsa con éxito! 🎀
                </div>
              )}

              {/* Features list */}
              <div className="bg-[#FFF5F8] p-5 rounded-2xl border border-[#FFD6E8] space-y-2 mt-4">
                <span className="font-label text-[10px] text-[#1A1A1A] block mb-2">
                  Detalles y Características Soft:
                </span>
                <ul className="space-y-2 text-xs text-[#6B5A60]">
                  {product.features.map((feature, idx) => (
                    <li key={idx} className="flex items-center gap-2.5">
                      <span className="w-2 h-2 bg-[#FFD6E8] rounded-full border border-[#1A1A1A]/20 flex-shrink-0" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
              </div>

            </div>

          </div>

        </div>
      </div>
    </div>
  );
};

export default ProductDetail;
