/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/


import React from 'react';
import { JOURNAL_ARTICLES } from '../constants';
import { JournalArticle } from '../types';

interface JournalProps {
  onArticleClick: (article: JournalArticle) => void;
}

const Journal: React.FC<JournalProps> = ({ onArticleClick }) => {
  return (
    <section id="journal" className="bg-gradient-to-b from-[#FFF5F8] to-[#FCE7F3] py-24 px-6 md:px-12">
      <div className="max-w-[1800px] mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-end mb-12 pb-6 border-b border-dashed border-[#FFD6E8]">
            <div>
                <span className="font-label text-[10px] uppercase tracking-[0.12em] text-[#1A1A1A] bg-[#FFD6E8] px-3.5 py-1 rounded-full border border-[#FFD6E8] inline-block mb-3">
                  🎀 Editorial & Estilo Soft
                </span>
                <h2 className="text-4xl md:text-5xl font-title font-extrabold text-[#1A1A1A]">
                  Diario Coco Rose
                </h2>
            </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {JOURNAL_ARTICLES.map((article) => (
                <div 
                  key={article.id} 
                  className="group cursor-pointer flex flex-col text-left bg-white p-6 rounded-3xl border border-[#FFD6E8] shadow-[0_8px_24px_rgba(255,214,232,0.4)] hover:shadow-[0_12px_32px_rgba(255,214,232,0.6)] transition-all" 
                  onClick={() => onArticleClick(article)}
                >
                    <div className="w-full aspect-[4/3] overflow-hidden mb-6 bg-[#FFF5F8] rounded-2xl border border-[#FFD6E8]">
                        <img 
                            src={article.image} 
                            alt={article.title} 
                            className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                        />
                    </div>
                    <div className="flex flex-col flex-1 text-left space-y-2">
                        <span className="font-label text-[9px] uppercase text-[#C87D8E] bg-[#FFF5F8] px-2.5 py-0.5 rounded-full border border-[#FFD6E8] w-fit">
                          {article.date}
                        </span>
                        <h3 className="text-xl font-title font-bold text-[#1A1A1A] group-hover:text-[#C87D8E] transition-colors leading-snug">
                          {article.title}
                        </h3>
                        <p className="text-xs text-[#6B5A60] font-normal leading-relaxed">
                          {article.excerpt}
                        </p>
                    </div>
                </div>
            ))}
        </div>
      </div>
    </section>
  );
};

export default Journal;
