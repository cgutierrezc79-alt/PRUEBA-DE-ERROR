/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/


import React from 'react';

const About: React.FC = () => {
  return (
    <section id="about" className="bg-[#FFF5F8]">
      
      {/* Introduction / Story */}
      <div className="py-20 px-6 md:px-12 max-w-[1800px] mx-auto flex flex-col md:flex-row items-start gap-12 md:gap-24">
        <div className="md:w-1/3 space-y-3">
          <span className="font-label text-[10px] uppercase tracking-[0.12em] text-[#1A1A1A] bg-[#FFD6E8] px-3.5 py-1 rounded-full border border-[#FFD6E8] inline-block">
            🎀 NUESTRA FILOSOFÍA
          </span>
          <h2 className="text-4xl md:text-5xl font-title font-extrabold text-[#1A1A1A] leading-tight">
            Nacido de la dulzura, <br/> concebido para tu estilo.
          </h2>
        </div>
        <div className="md:w-2/3 max-w-2xl space-y-6">
          <p className="text-base md:text-lg text-[#6B5A60] font-normal leading-relaxed">
            Coco Rose nació bajo la filosofía de la estética soft girl, coquette y balletcore: prendas, accesorios y objetos que despiertan ternura, sofisticación y comodidad en tu día a día.
          </p>
          <p className="text-base md:text-lg text-[#6B5A60] font-normal leading-relaxed">
            Diseñamos piezas con alma artesanal, encajes suaves y tonos pastel serenos que celebran la feminidad dulce pero elevada.
          </p>
          <div className="card-softgirl p-3 rounded-3xl overflow-hidden mt-8">
            <img 
              src="https://images.pexels.com/photos/6583355/pexels-photo-6583355.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1" 
              alt="Estudio Coco Rose" 
              className="w-full h-[380px] object-cover rounded-2xl border border-[#FFD6E8]"
            />
          </div>
          <p className="font-label text-[10px] uppercase text-[#6B5A60] mt-2">
            Estudio Coco Rose • París & Kioto 🎀
          </p>
        </div>
      </div>

      {/* Philosophy Blocks */}
      <div className="grid grid-cols-1 lg:grid-cols-2 min-h-[60vh]">
        <div className="relative h-[400px] lg:h-auto overflow-hidden group">
           <img 
             src="https://images.unsplash.com/photo-1618220179428-22790b461013?auto=format&fit=crop&q=80&w=1200" 
             alt="Texturas Soft" 
             className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
           />
        </div>
        <div className="flex flex-col justify-center p-10 lg:p-20 bg-[#FCE7F3] space-y-4">
           <span className="font-label text-[10px] uppercase tracking-[0.12em] text-[#1A1A1A] bg-[#FFD6E8] px-3.5 py-1 rounded-full border border-[#FFD6E8] w-fit">
             ✨ Materialidad Soft
           </span>
           <h3 className="text-3xl md:text-4xl font-title font-extrabold text-[#1A1A1A] leading-tight">
             Fibras delicadas y <br/> detalles de lazo.
           </h3>
           <p className="text-sm md:text-base text-[#6B5A60] font-normal leading-relaxed max-w-md">
             Cada prenda de Coco Rose combina lino lavado, algodón peinado y cintas de satén en acabados resistentes que cuidan tu piel.
           </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 min-h-[60vh]">
        <div className="flex flex-col justify-center p-10 lg:p-20 bg-[#E9D5FF] text-[#1A1A1A] space-y-4">
           <span className="font-label text-[10px] uppercase tracking-[0.12em] text-[#1A1A1A] bg-white px-3.5 py-1 rounded-full border border-[#FFD6E8] w-fit font-bold">
             🎀 Sección Glam
           </span>
           <h3 className="text-3xl md:text-4xl font-title font-extrabold text-[#1A1A1A] leading-tight">
             Harmonía y Coquette Vibe.
           </h3>
           <p className="text-sm md:text-base text-[#1A1A1A]/80 font-normal leading-relaxed max-w-md">
             Nuestras colecciones equilibran tonos rosa polvo, lila suave y accesorios en tonos pastel para elevar tus momentos cotidianos.
           </p>
        </div>
        <div className="relative h-[400px] lg:h-auto overflow-hidden group">
           <img 
             src="https://images.pexels.com/photos/6801917/pexels-photo-6801917.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1" 
             alt="Coquette aesthetic moment" 
             className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
           />
        </div>
      </div>
    </section>
  );
};

export default About;