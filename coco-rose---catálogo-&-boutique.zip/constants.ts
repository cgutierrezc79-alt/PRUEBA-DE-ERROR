/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/

import React from 'react';
import { Product, JournalArticle } from './types';

export const PRODUCTS: Product[] = [
  // PRENDAS (CLOTHING & GARMENTS)
  {
    id: 'p-kimono',
    name: 'Kimono Lino Orgánico',
    tagline: 'Fluidez y serenidad táctil.',
    description: 'Confeccionado en 100% lino orgánico lavado en piedra para una caída suave y transpirable.',
    longDescription: 'El Kimono Coco Rose está diseñado para envolver el cuerpo con ligereza. Confeccionado en lino orgánico de cultivo sostenible en Europa, lavado con piedra natural para lograr una textura arrugada artesanal y agradable al contacto con la piel. Ideal para sobreponer en capas durante mañanas frescas o tardes calurosas.',
    price: 185,
    category: 'Prendas',
    material: '100% Lino Orgánico Europeo',
    sizes: ['XS/S', 'M/L', 'XL/2XL'],
    colors: [
      { name: 'Rosa Polvo', hex: '#EACED3' },
      { name: 'Arena Caliza', hex: '#D8D0C5' },
      { name: 'Marfil Natural', hex: '#F0ECE1' }
    ],
    imageUrl: 'https://images.unsplash.com/photo-1548883354-7622d03aca27?auto=format&fit=crop&q=80&w=1000',
    gallery: [
      'https://images.unsplash.com/photo-1548883354-7622d03aca27?auto=format&fit=crop&q=80&w=1000',
      'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&q=80&w=1000'
    ],
    features: ['Tejido 100% Lino Respirable', 'Teñido Botánico Hipoalergénico', 'Corte Oversized Unisex'],
    inStock: true,
    rating: 4.9,
    reviewsCount: 38,
    isNew: true
  },
  {
    id: 'p-camisa',
    name: 'Camisa Slub Algodón Orgánico',
    tagline: 'Estructura relajada.',
    description: 'Camisa minimalista en algodón flameado con textura táctil y botones de nácar natural.',
    longDescription: 'Nuestra Camisa Slub redefine el básico diario. Su hilo de algodón peinado con variación de grosor crea un patrón irregular lleno de carácter. Corte recto y hombros ligeramente caídos para máximo confort en cualquier estación del año.',
    price: 140,
    category: 'Prendas',
    material: '100% Algodón Flameado Orgánico GOTS',
    sizes: ['S', 'M', 'L', 'XL'],
    colors: [
      { name: 'Blanco Ópalo', hex: '#F7F5F0' },
      { name: 'Verde Oliva Suave', hex: '#8B947E' },
      { name: 'Arena Tostada', hex: '#C2B69D' }
    ],
    imageUrl: 'https://images.unsplash.com/photo-1598033129183-c4f50c736f10?auto=format&fit=crop&q=80&w=1000',
    gallery: [
      'https://images.unsplash.com/photo-1598033129183-c4f50c736f10?auto=format&fit=crop&q=80&w=1000',
      'https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?auto=format&fit=crop&q=80&w=1000'
    ],
    features: ['Botones de Nácar Reciclado', 'Puño Ajustable Doble', 'Planchado Mínimo Natural'],
    inStock: true,
    rating: 4.8,
    reviewsCount: 24,
    isNew: false
  },
  {
    id: 'p-jersey',
    name: 'Jersey Knit Alpaca & Seda',
    tagline: 'Calidez ultra ligera.',
    description: 'Suéter de punto artesanal elaborado con hilado de alpaca baby peruana y seda natural.',
    longDescription: 'Tejido en telares de baja velocidad para mantener el volumen suelto del hilo. La mezcla de alpaca y seda proporciona un aislamiento térmico superior sin aportar peso. Un básico atemporal diseñado para durar décadas.',
    price: 220,
    category: 'Prendas',
    material: '70% Alpaca Baby, 30% Seda Mulberri',
    sizes: ['XS', 'S', 'M', 'L'],
    colors: [
      { name: 'Terracota Cálida', hex: '#B86B53' },
      { name: 'Crudo Hueso', hex: '#EAE5D9' },
      { name: 'Gris Bruma', hex: '#9E9B95' }
    ],
    imageUrl: 'https://images.unsplash.com/photo-1576995853123-5a10305d93c0?auto=format&fit=crop&q=80&w=1000',
    gallery: [
      'https://images.unsplash.com/photo-1576995853123-5a10305d93c0?auto=format&fit=crop&q=80&w=1000',
      'https://images.unsplash.com/photo-1620799140408-edc6dcb6d633?auto=format&fit=crop&q=80&w=1000'
    ],
    features: ['Fibra Ultra Suave Hipoalergénica', 'Regulación Térmica Natural', 'Corte Acanalado en Puños y Ruedo'],
    inStock: true,
    rating: 5.0,
    reviewsCount: 19,
    isNew: true
  },
  {
    id: 'p-pantalon',
    name: 'Pantalón Fluido Lino & Algodón',
    tagline: 'Libertad de movimiento.',
    description: 'Pantalón de tiro alto y pierna ancha con pretina elástica posterior y pliegues frontales.',
    longDescription: 'Diseñado para aportar soltura sin perder sofisticación. Su tejido mixto de lino y algodón aporta la rigidez justa para mantener la caída y la suavidad del algodón en contacto con la piel.',
    price: 165,
    category: 'Prendas',
    material: '55% Lino, 45% Algodón Orgánico',
    sizes: ['S', 'M', 'L', 'XL'],
    colors: [
      { name: 'Piedra Cálida', hex: '#C2BBB0' },
      { name: 'Negro Ceniza', hex: '#2B2927' }
    ],
    imageUrl: 'https://images.unsplash.com/photo-1509631179647-0177331693ae?auto=format&fit=crop&q=80&w=1000',
    gallery: [
      'https://images.unsplash.com/photo-1509631179647-0177331693ae?auto=format&fit=crop&q=80&w=1000'
    ],
    features: ['Pretina Adaptable Flex', 'Bolsillos Profundos Laterales', 'Caída Ancha Reposada'],
    inStock: true,
    rating: 4.7,
    reviewsCount: 15,
    isNew: false
  },
  {
    id: 'p-chaqueta',
    name: 'Chaqueta Studio Canvas',
    tagline: 'Utilitarismo artesanal.',
    description: 'Chaqueta estructurada en lona pesada de algodón vegetal con costuras reforzadas.',
    longDescription: 'Inspirada en los sacos de trabajo de taller. Cuenta con cuatro bolsillos frontales simétricos, cuello de solapa suave y botones de madera de roble pulidos a mano.',
    price: 260,
    category: 'Prendas',
    material: '100% Lona de Algodón Reciclado 380gsm',
    sizes: ['S', 'M', 'L', 'XL'],
    colors: [
      { name: 'Marrón Arcilla', hex: '#8C5E47' },
      { name: 'Verde Pino Mate', hex: '#4A584E' }
    ],
    imageUrl: 'https://images.unsplash.com/photo-1551028719-00167b16eac5?auto=format&fit=crop&q=80&w=1000',
    gallery: [
      'https://images.unsplash.com/photo-1551028719-00167b16eac5?auto=format&fit=crop&q=80&w=1000'
    ],
    features: ['4 Bolsillos Funcionales', 'Botones de Roble Sustentable', 'Tratamiento Repelente al Agua'],
    inStock: true,
    rating: 4.9,
    reviewsCount: 31,
    isNew: true
  },
  {
    id: 'p-bufanda',
    name: 'Bufanda Cashmere & Lana Fina',
    tagline: 'Envolvente y serena.',
    description: 'Bufanda extra larga de tacto esponjoso con flecos terminados a mano.',
    longDescription: 'Tejida con una mezcla delicada de lana merina de micraje ultra fino y cashmere seleccionada. Perfecta para proteger del viento con elegancia sobria.',
    price: 115,
    category: 'Prendas',
    material: '85% Lana Merina Fina, 15% Cashmere',
    sizes: ['Talla Única (200x65 cm)'],
    colors: [
      { name: 'Arena Avena', hex: '#DDD6C9' },
      { name: 'Musgo Suave', hex: '#6E7569' }
    ],
    imageUrl: 'https://images.unsplash.com/photo-1520903920243-00d872a2d1c9?auto=format&fit=crop&q=80&w=1000',
    gallery: [
      'https://images.unsplash.com/photo-1520903920243-00d872a2d1c9?auto=format&fit=crop&q=80&w=1000'
    ],
    features: ['Acabado Esponjoso Peinado', 'Flecos Artesanales Anudados', 'Lana Ética Mulesing-Free'],
    inStock: true,
    rating: 4.8,
    reviewsCount: 22,
    isNew: false
  },

  // ACCESORIOS & OBJETOS PERSONALES
  {
    id: 'p-tote',
    name: 'Bolso Tote Lino Denso & Cuero',
    tagline: 'Capacidad y textura.',
    description: 'Tote versátil confeccionado en lona de lino de alto gramaje con asas de cuero curtido vegetal.',
    longDescription: 'Un bolso amplio diseñado para acompañar tus jornadas de trabajo o escapadas. El lino denso de 450g aguanta el uso diario mientras adquiere flexibilidad con los años. Incluye compartimento interno acolchado para portátil de hasta 16".',
    price: 210,
    category: 'Accesorios',
    material: 'Lino Denso 450g & Cuero Curtido Vegetal',
    sizes: ['Única (42x38x14 cm)'],
    colors: [
      { name: 'Lino Crudo / Cuero Cognac', hex: '#CDBCA2' },
      { name: 'Negro Obsidiana', hex: '#1F1E1C' }
    ],
    imageUrl: 'https://images.unsplash.com/photo-1544816155-12df9643f363?auto=format&fit=crop&q=80&w=1000',
    gallery: [
      'https://images.unsplash.com/photo-1544816155-12df9643f363?auto=format&fit=crop&q=80&w=1000'
    ],
    features: ['Funda Interna para Laptop', 'Cierre Magnético Oculto', 'Asas de Cuero Curtido al Vegetal'],
    inStock: true,
    rating: 4.9,
    reviewsCount: 42,
    isNew: true
  },
  {
    id: 'p-ceramica',
    name: 'Set de Cerámica Sandstone Tea',
    tagline: 'Ritual del té diario.',
    description: 'Juego de tetera y dos cuencos modelados a mano en gres con esmalte mate mineral.',
    longDescription: 'Cada pieza es moldeada individualmente en nuestro taller asociado. La textura exterior de gres sin esmaltar proporciona un agarre cálido y rugoso, mientras que el interior está vitrificado para retener el calor de tus infusiones.',
    price: 95,
    category: 'Hogar & Objetos',
    material: 'Gres Natural de Arenisca',
    sizes: ['Tetera 600ml + 2 Cuencos 180ml'],
    colors: [
      { name: 'Terracota Volcánica', hex: '#A35D43' },
      { name: 'Arena Tiza', hex: '#DFD8CC' }
    ],
    imageUrl: 'https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&q=80&w=1000',
    gallery: [
      'https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&q=80&w=1000'
    ],
    features: ['Moldeado Manual Artesanal', 'Esmalte Libre de Plomo', 'Resistente al Lavavajillas'],
    inStock: true,
    rating: 5.0,
    reviewsCount: 18,
    isNew: true
  },

  // TECNOLOGÍA ORGÁNICA & AUDIO
  {
    id: 'p1',
    name: 'Aura Harmony',
    tagline: 'Audio de campo abierto.',
    description: 'Auriculares circumaurales envueltos en tejido acústico orgánico y compuesto de arenisca.',
    longDescription: 'Siente el sonido como una brisa natural. Los auriculares Aura Harmony cuentan con drivers de campo abierto que eliminan la presión auditiva. Su diadema de compuesto mineral reciclado y almohadillas de lino transpirable te permiten disfrutar durante horas.',
    price: 429,
    category: 'Audio & Tech',
    material: 'Compuesto de Arenisca Reciclada y Tejido Acústico',
    sizes: ['Ajuste Universal Ergonomico'],
    colors: [
      { name: 'Piedra Caliza', hex: '#C2BBB0' },
      { name: 'Carbón Mate', hex: '#3B3835' }
    ],
    imageUrl: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&q=80&w=1000',
    gallery: [
      'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&q=80&w=1000',
      'https://images.unsplash.com/photo-1484704849700-f032a568e944?auto=format&fit=crop&q=80&w=1000'
    ],
    features: ['Cancelación de Ruido Natural Orgánica', '50 Horas de Batería', 'Carga Inalámbrica por Contacto'],
    inStock: true,
    rating: 4.9,
    reviewsCount: 86,
    isNew: false
  },
  {
    id: 'p2',
    name: 'Aura Epoch Watch',
    tagline: 'Momentos, no minutos.',
    description: 'Reloj inteligente de descanso visual con caja cerámica y correa de cuero vegano.',
    longDescription: 'El tiempo no es una cuenta regresiva. Aura Epoch reemplaza las notificaciones invasivas por un panel híbrido E-Ink mate que imita la textura del papel. Monitorea tu variabilidad de ritmo cardíaco y niveles de estrés con sutiles impulsos táctiles.',
    price: 349,
    category: 'Audio & Tech',
    material: 'Caja Cerámica Pulida & Correa de Cuero de Piña',
    sizes: ['38mm', '42mm'],
    colors: [
      { name: 'Blanco Porcelana', hex: '#F4F2EC' },
      { name: 'Negro Órice', hex: '#232220' }
    ],
    imageUrl: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&q=80&w=1000',
    gallery: [
      'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&q=80&w=1000'
    ],
    features: ['Pantalla E-Ink Anti-Reflejo', 'Sensor de Respiración y Estrés', 'Batería de 7 Días'],
    inStock: true,
    rating: 4.8,
    reviewsCount: 54,
    isNew: false
  },
  {
    id: 'p4',
    name: 'Aura Essence Purificador',
    tagline: 'Escultura de aire limpio.',
    description: 'Purificador bio-filtro con musgo vivo y aromaterapia de notas botánicas.',
    longDescription: 'Combina filtración HEPA de alta eficiencia con un bio-filtro activo de musgo hidropónico. Elimina el 99.9% de micropartículas mientras mantiene la humedad ambiental idónea para tus vías respiratorias.',
    price: 599,
    category: 'Hogar & Objetos',
    material: 'Cuerpo Cerámico Molded & Musgo Hidropónico',
    sizes: ['Estándar (35cm alto x 22cm ø)'],
    colors: [
      { name: 'Blanco Tiza', hex: '#EBE7DE' }
    ],
    imageUrl: 'https://images.pexels.com/photos/8092420/pexels-photo-8092420.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    gallery: [
      'https://images.pexels.com/photos/8092420/pexels-photo-8092420.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
    ],
    features: ['Filtro Bio-HEPA Silencioso', 'Difusor de Aceites Esenciales', 'Modo Noche Susurro (<18dB)'],
    inStock: true,
    rating: 4.9,
    reviewsCount: 29,
    isNew: false
  },
  {
    id: 'p5',
    name: 'Aura Beam Lámpara',
    tagline: 'Luz que sincroniza tu ritmo.',
    description: 'Lámpara circadiana con atenuación de tono vela y control gestual por proximidad.',
    longDescription: 'Sincroniza su temperatura de color con la salida y puesta del sol local. Elimina la luz azul a partir del atardecer para favorecer la producción natural de melatonina antes de dormir.',
    price: 249,
    category: 'Hogar & Objetos',
    material: 'Madera de Roble Blanco & Difusor Soplado',
    sizes: ['Mesa (28 cm)'],
    colors: [
      { name: 'Roble Natural', hex: '#C7B299' }
    ],
    imageUrl: 'https://images.unsplash.com/photo-1565814329452-e1efa11c5b89?auto=format&fit=crop&q=80&w=1000',
    gallery: [
      'https://images.unsplash.com/photo-1565814329452-e1efa11c5b89?auto=format&fit=crop&q=80&w=1000'
    ],
    features: ['Ajuste Circadiano Automático', 'Sensor Gestual Touchless', 'Regulación Dim-to-Warm'],
    inStock: true,
    rating: 4.7,
    reviewsCount: 33,
    isNew: false
  }
];

export const JOURNAL_ARTICLES: JournalArticle[] = [
    {
        id: 1,
        title: "The Psychology of Texture",
        date: "April 12, 2025",
        excerpt: "Why our fingertips crave natural surfaces in a world of glass and plastic.",
        image: "https://images.unsplash.com/photo-1617791160505-6f00504e3519?auto=format&fit=crop&q=80&w=1000",
        content: React.createElement(React.Fragment, null,
            React.createElement("p", { className: "mb-6 first-letter:text-5xl first-letter:font-serif first-letter:mr-3 first-letter:float-left text-[#5D5A53]" },
                "We live in a frictionless world. Our phones are smooth glass, our laptops polished aluminum, our countertops engineered quartz. There is no resistance, no grit, no grain. And yet, our biology craves it."
            ),
            React.createElement("p", { className: "mb-8 text-[#5D5A53]" },
                "The fingertips are among the most densely innervated parts of the human body. They are designed to read the story of an object—its age, its origin, its temperature. When we deny them this input, we experience a subtle form of sensory deprivation."
            ),
            React.createElement("blockquote", { className: "border-l-2 border-[#2C2A26] pl-6 italic text-xl text-[#2C2A26] my-10 font-serif" },
                "\"To touch is to know. To feel is to be grounded.\""
            ),
            React.createElement("p", { className: "mb-6 text-[#5D5A53]" },
                "At Aura, we design for the hand as much as for the eye. We choose materials that have a voice. Sandstone that warms under your palm. Fabric that has a weave you can trace. Wood that remembers the forest."
            )
        )
    },
    {
        id: 2,
        title: "Living with Less",
        date: "March 28, 2025",
        excerpt: "A conversation with architect Hiroshi Nakamura on the art of empty space.",
        image: "https://images.unsplash.com/photo-1494438639946-1ebd1d20bf85?auto=format&fit=crop&q=80&w=1000",
        content: React.createElement(React.Fragment, null,
            React.createElement("p", { className: "mb-6 text-[#5D5A53]" },
                "Emptiness is not nothing. In Japanese architecture, the concept of ",
                React.createElement("em", null, "Ma"),
                " refers to the space between things—the pause that gives shape to the whole."
            ),
            React.createElement("p", { className: "mb-8 text-[#5D5A53]" },
                "\"We tend to fill our lives with noise,\" Nakamura says, sipping tea in his studio overlooking the rain-slicked streets of Kyoto. \"We buy more devices to save time, but we end up with less time than ever. True luxury is the absence of intrusion.\""
            ),
            React.createElement("div", { className: "my-12 p-8 bg-[#EBE7DE] font-serif text-[#2C2A26] italic text-center" },
                React.createElement("p", null, "The room is empty"),
                React.createElement("p", null, "But full of light."),
                React.createElement("p", null, "The mind is quiet"),
                React.createElement("p", null, "But full of thought."),
                React.createElement("p", null, "This is the weight"),
                React.createElement("p", null, "Of living with less.")
            ),
            React.createElement("p", { className: "mb-6 text-[#5D5A53]" },
                "This philosophy drives every curve of our new collection. We asked ourselves: what can we remove? How much can we take away until only the essential remains?"
            )
        )
    },
    {
        id: 3,
        title: "Spring Moodboard",
        date: "March 15, 2025",
        excerpt: "Notes from the design studio: morning mist, wet stone, and pale linen.",
        image: "https://images.unsplash.com/photo-1516834474-48c0abc2a902?auto=format&fit=crop&q=80&w=1000",
        content: React.createElement(React.Fragment, null,
            React.createElement("p", { className: "mb-6 text-[#5D5A53]" },
                "Spring in the studio is a time of awakening. The light shifts from the harsh, low angles of winter to a softer, diffused glow. We find ourselves drawn to paler tones—the grey of wet pavement, the cream of unbleached linen, the dusty green of sage."
            ),
            React.createElement("p", { className: "mb-8 text-[#5D5A53]" },
                "Our moodboard this month is a study in softness. It is about the transition state—neither cold nor hot, neither dark nor bright. It is the dawn of the year."
            ),
             React.createElement("div", { className: "my-12 p-8 bg-[#2C2A26] text-[#F5F2EB] font-serif italic text-center" },
                React.createElement("p", null, "Green sprout pushing through"),
                React.createElement("p", null, "Grey stone cold against the skin"),
                React.createElement("p", null, "The sun warms the air.")
            )
        )
    }
];

export const BRAND_NAME = 'Coco Rose';
export const PRIMARY_COLOR = 'stone-900'; 
export const ACCENT_COLOR = 'stone-500';